#!/usr/bin/env sh
						


export YARN_RESOURCEMANAGER_OPTS="-Xms1G -Xmx8G"
export YARN_TIMELINESERVER_OPTS="-Xms700m -Xmx8G"
