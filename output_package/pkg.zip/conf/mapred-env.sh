#!/usr/bin/env sh
export HADOOP_JOB_HISTORYSERVER_OPTS="-Xms700m -Xmx8G"
